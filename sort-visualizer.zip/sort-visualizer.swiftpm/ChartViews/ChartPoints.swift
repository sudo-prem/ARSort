import Foundation

struct ChartPoints: Identifiable {
    var size: Int
    var time: Float
    var id = UUID()
}
